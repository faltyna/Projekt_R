$(document).ready(function() {
    alert("Strona została poprawnie załadowana");
  });
  

  $(document).ready(function() {
    $("#paragraf1, #paragraf2").hover(function() {
      $(this).css("background-color", "FireBrick");
      $(this).css("color", "White");
    }, function() {
      $(this).css("background-color", "");
      $(this).css("color", "");
    });
  });
  

  $(document).ready(function() {
    $("#paragraf1","#paragraf2").hover(function() {
      $(this).css("text-align", "center");
    }, function() {
      $(this).css("text-align", "");
    });
  });

  $(document).ready(function() {
    $("#ukryj").click(() => {
      $('#sekcja1').hide();
      $('#sekcja2').hide();
    });
    $("")
    $("#pokaz").click(() => {
      $('#sekcja1').show();
      $('#sekcja2').show();
    });
  });
  

  function scroll(e) {
    const href = $(this).attr('href');
  
    e.preventDefault();
  
    $('html, body').animate(
      {
        scrollTop: $(href).offset().top,
      },
      800,
    );
  
    location.hash = href;
  }
  
  $('a[href^="#"]').click(scroll);

  $(document).ready(function() {
    if ($(window).scrollTop() < 600) {
      $('.side-menu').hide();
    } else {
      $('.side-menu').show();
    }
    if ($('.side-menu').is(':visible')) {
      $('nav.top-nav').hide();
    } else {
      $('nav.top-nav').show();
    }
  
    $(window).on('scroll', function() {
      if ($(window).scrollTop() < 600) {
        $('.side-menu').hide();
      } else {
        $('.side-menu').show();
      }
      if ($('.side-menu').is(':visible')) {
        $('nav.top-nav').hide();
      } else {
        $('nav.top-nav').show();
      }
    });
  });
  